
public class Angestellte {

}
